#! /bin/sh
git log -n 1 --pretty="format:%H"
