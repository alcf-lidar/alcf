from cmor_const import *

from pywrapper import setup, load_table, set_table, close, set_cur_dataset_attribute, get_cur_dataset_attribute, has_cur_dataset_attribute, set_variable_attribute, list_variable_attributes, get_variable_attribute, has_variable_attribute, check_institution, check_sourceID, check_experiment, check_grids, check_requiredattributes, check_ISOTime, check_furtherinfourl, get_CV_Error, setup_variable, set_CV_Error, reset_CV_Error, check_parentExpID, check_subExpID, check_filename
