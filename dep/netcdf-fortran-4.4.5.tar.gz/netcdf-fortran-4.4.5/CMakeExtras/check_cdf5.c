#include <netcdf_meta.h>
#if !defined(NC_HAS_CDF5) || NC_HAS_CDF5 == 0
      choke me
#endif
int main() {return 0;}
