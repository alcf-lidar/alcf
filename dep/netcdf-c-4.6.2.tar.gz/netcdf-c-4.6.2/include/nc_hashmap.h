#ifndef HASHMAP_H_INCLUDED
#define HASHMAP_H_INCLUDED
#include <stdlib.h>

/** Hashmap structure (forward declaration) */
struct s_hashmap;
typedef struct s_hashmap NC_hashmap;



#endif
