This directory contains various scripts for debugging by Dennis
Heimbigner @ Unidata.
USE AT YOUR OWN PERIL.


